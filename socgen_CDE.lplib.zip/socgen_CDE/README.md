# socgen_CDE
socgen common design environment
